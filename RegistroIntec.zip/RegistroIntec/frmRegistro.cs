﻿//using Amazon.Rekognition.Model;
//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
//using System.Drawing;
//using System.IO;
//using System.Linq;
//using System.Windows.Forms;
//using Amazon.Rekognition;
//using Amazon;
//using iText.Kernel.Pdf;
//using iText.Layout;
//using iText.Layout.Element;

//namespace RegistroIntec
//{
//    public partial class frmRegistro : Form
//    {
//        AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient("your_access_key", "your_secret_key", RegionEndpoint.USEast1);

//        private const decimal InscriptionFee = 10000m;

//        public frmRegistro()
//        {
//            InitializeComponent();
//        }
//        private void btnCargarImagen_Click(object sender, EventArgs e)
//        {
//            OpenFileDialog ofdArchivo = new OpenFileDialog();
//            ofdArchivo.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
//            ofdArchivo.Title = "Seleccionar una imagen";

//            if (ofdArchivo.ShowDialog() == DialogResult.OK)
//            {
//                string photo = ofdArchivo.FileName;
//                pbImage.ImageLocation = photo;
//            }
//        }

//        private void btnAceptar_Click(object sender, EventArgs e)
//        {
//            OpenFileDialog ofdArchivo = new OpenFileDialog();
//            if (ofdArchivo.ShowDialog() != DialogResult.OK) return;

//            string photo = ofdArchivo.FileName;
//            pbImage.ImageLocation = photo;

//            Amazon.Rekognition.Model.Image rekognitionImage = new Amazon.Rekognition.Model.Image();
//            byte[] imageData;

//            try
//            {
//                using (FileStream fs = new FileStream(photo, FileMode.Open, FileAccess.Read))
//                {
//                    imageData = new byte[fs.Length];
//                    fs.Read(imageData, 0, (int)fs.Length);
//                    rekognitionImage.Bytes = new MemoryStream(imageData);
//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error al cargar la imagen: " + ex.Message);
//                return;
//            }

//            DetectFacesRequest faceRequest = new DetectFacesRequest
//            {
//                Image = rekognitionImage,
//                Attributes = new List<string> { "ALL" }
//            };

//            DetectModerationLabelsRequest moderationRequest = new DetectModerationLabelsRequest
//            {
//                Image = rekognitionImage
//            };

//            RecognizeCelebritiesRequest celebrityRequest = new RecognizeCelebritiesRequest
//            {
//                Image = rekognitionImage
//            };

//            try
//            {
//                var faceResponse = rekognitionClient.DetectFacesAsync(faceRequest).Result;
//                var moderationResponse = rekognitionClient.DetectModerationLabelsAsync(moderationRequest).Result;
//                var celebrityResponse = rekognitionClient.RecognizeCelebritiesAsync(celebrityRequest).Result;

//                if (moderationResponse.ModerationLabels.Any(label => label.ParentName == "Explicit Nudity" || label.ParentName == "Violence"))
//                {
//                    MessageBox.Show("La imagen no es apta para todo público.");
//                    return;
//                }

//                decimal pago = InscriptionFee;
//                if (celebrityResponse.CelebrityFaces.Count > 0)
//                {
//                    pago *= 0.9m; // 10% de descuento
//                }

//                InsertStudentToDatabase(imageData, pago);
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error al procesar la imagen: " + ex.Message);
//            }
//        }

//        private void InsertStudentToDatabase(byte[] foto, decimal pago)
//        {
//            string tipoDocumento = cmbTipoDoc.SelectedItem?.ToString();
//            string documento = txtDoc.Text;
//            string nombres = txtNombre.Text;
//            string apellidos = txtApellido.Text;
//            DateTime fechaNacimiento;
//            if (!DateTime.TryParse(txtFechaNacimiento.Text, out fechaNacimiento))
//            {
//                MessageBox.Show("Fecha de nacimiento inválida.");
//                return;
//            }
//            string sexo = txtSexo.Text;
//            string carrera = txtCarrera.Text;

//            try
//            {
//                string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\mami\\source\\repos\\RegistroIntec\\IntecRegistro.mdf;Integrated Security=True";

//                using (SqlConnection connection = new SqlConnection(connectionString))
//                {
//                    connection.Open();

//                    SqlCommand cmd = new SqlCommand("InsertStudent", connection);
//                    cmd.CommandType = CommandType.StoredProcedure;

//                    cmd.Parameters.Add("@TipoDocumento", SqlDbType.NVarChar, 50).Value = tipoDocumento;
//                    cmd.Parameters.Add("@Documento", SqlDbType.NVarChar, 50).Value = documento;
//                    cmd.Parameters.Add("@Nombres", SqlDbType.NVarChar, 100).Value = nombres;
//                    cmd.Parameters.Add("@Apellidos", SqlDbType.NVarChar, 100).Value = apellidos;
//                    cmd.Parameters.Add("@FechaNacimiento", SqlDbType.Date).Value = fechaNacimiento;
//                    cmd.Parameters.Add("@Sexo", SqlDbType.NVarChar, 10).Value = sexo;
//                    cmd.Parameters.Add("@Foto", SqlDbType.VarBinary, -1).Value = foto;
//                    cmd.Parameters.Add("@Carrera", SqlDbType.NVarChar, 100).Value = carrera;
//                    cmd.Parameters.Add("@Pago", SqlDbType.Decimal).Value = pago;

//                    cmd.ExecuteNonQuery();

//                    MessageBox.Show("Estudiante registrado exitosamente.");
//                    ImprimirRecibo(tipoDocumento, documento, nombres, apellidos, fechaNacimiento, sexo, carrera, pago);
//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error al registrar estudiante en la base de datos: " + ex.Message);
//            }
//        }

//        private void ImprimirRecibo(string tipoDocumento, string documento, string nombres, string apellidos, DateTime fechaNacimiento, string sexo, string carrera, decimal pago)
//        {
//            string recibo = $"Recibo de Inscripción\n\n" +
//                            $"Tipo de Documento: {tipoDocumento}\n" +
//                            $"Documento: {documento}\n" +
//                            $"Nombres: {nombres}\n" +
//                            $"Apellidos: {apellidos}\n" +
//                            $"Fecha de Nacimiento: {fechaNacimiento.ToShortDateString()}\n" +
//                            $"Sexo: {sexo}\n" +
//                            $"Carrera: {carrera}\n" +
//                            $"Monto Pagado: RD${pago}\n" +
//                            $"Fecha: {DateTime.Now.ToShortDateString()}";

//            SaveFileDialog sfd = new SaveFileDialog
//            {
//                Filter = "PDF files (*.pdf)|*.pdf",
//                FileName = $"Recibo_Inscripcion_{nombres}.pdf"
//            };

//            if (sfd.ShowDialog() == DialogResult.OK)
//            {
//                try
//                {
//                    using (PdfWriter writer = new PdfWriter(sfd.FileName))
//                    {
//                        using (PdfDocument pdf = new PdfDocument(writer))
//                        {
//                            Document document = new Document(pdf);
//                            document.Add(new Paragraph(recibo));
//                            document.Close();
//                        }
//                    }
//                    MessageBox.Show("Recibo guardado exitosamente como PDF.");
//                }
//                catch (Exception ex)
//                {
//                    MessageBox.Show("Error al guardar el recibo: " + ex.Message);
//                }
//            }
//        }

//    }
//}

using Amazon.Rekognition.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Amazon.Rekognition;
using Amazon;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;

namespace RegistroIntec
{
    public partial class frmRegistro : Form
    {
        AmazonRekognitionClient rekognitionClient = new AmazonRekognitionClient("AKIAIE5LZMZN4CR6IO5Q", "xUtzMH5IxZmuZYrc9KSN83JE+pgf5J60+FajM65J", RegionEndpoint.USEast1); private const decimal InscriptionFee = 10000m;

        public frmRegistro()
        {
            InitializeComponent();
        }

        private void btnCargarImagen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofdArchivo = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp",
                Title = "Seleccionar una imagen"
            };

            if (ofdArchivo.ShowDialog() == DialogResult.OK)
            {
                string photo = ofdArchivo.FileName;
                pbImage.ImageLocation = photo;
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            string photo = pbImage.ImageLocation;
            if (string.IsNullOrEmpty(photo))
            {
                MessageBox.Show("Por favor, cargue una imagen primero.");
                return;
            }

            Amazon.Rekognition.Model.Image rekognitionImage = LoadImage(photo);
            if (rekognitionImage == null) return;

            var faceRequest = new DetectFacesRequest { Image = rekognitionImage, Attributes = new List<string> { "ALL" } };
            var moderationRequest = new DetectModerationLabelsRequest { Image = rekognitionImage };
            var celebrityRequest = new RecognizeCelebritiesRequest { Image = rekognitionImage };

            try
            {
                var faceResponse = rekognitionClient.DetectFacesAsync(faceRequest).Result;
                var moderationResponse = rekognitionClient.DetectModerationLabelsAsync(moderationRequest).Result;
                var celebrityResponse = rekognitionClient.RecognizeCelebritiesAsync(celebrityRequest).Result;

                if (moderationResponse.ModerationLabels.Any(label => label.ParentName == "Explicit Nudity" || label.ParentName == "Violence"))
                {
                    MessageBox.Show("La imagen no es apta para todo público.");
                    return;
                }

                decimal pago = InscriptionFee;
                if (celebrityResponse.CelebrityFaces.Count > 0)
                {
                    pago *= 0.9m; // 10% discount
                }

                InsertStudentToDatabase(rekognitionImage.Bytes.ToArray(), pago);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al procesar la imagen: " + ex.Message);
            }
        }

        private Amazon.Rekognition.Model.Image LoadImage(string photo)
        {
            try
            {
                using (FileStream fs = new FileStream(photo, FileMode.Open, FileAccess.Read))
                {
                    byte[] imageData = new byte[fs.Length];
                    fs.Read(imageData, 0, (int)fs.Length);
                    return new Amazon.Rekognition.Model.Image { Bytes = new MemoryStream(imageData) };
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la imagen: " + ex.Message);
                return null;
            }
        }

        // Insert student data into the database
        private void InsertStudentToDatabase(byte[] foto, decimal pago)
        {
            string tipoDocumento = cmbTipoDoc.SelectedItem?.ToString();
            string documento = txtDoc.Text;
            string nombres = txtNombre.Text;
            string apellidos = txtApellido.Text;
            DateTime fechaNacimiento;
            if (!DateTime.TryParse(txtFechaNacimiento.Text, out fechaNacimiento))
            {
                MessageBox.Show("Fecha de nacimiento inválida.");
                return;
            }
            string sexo = txtSexo.Text;
            string carrera = txtCarrera.Text;

            try
            {
                string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\mami\\source\\repos\\RegistroIntec\\IntecRegistro.mdf;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand cmd = new SqlCommand("ppInsertEstudiante", connection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };

                    cmd.Parameters.AddWithValue("@TipoDocumento", tipoDocumento);
                    cmd.Parameters.AddWithValue("@Documento", documento);
                    cmd.Parameters.AddWithValue("@Nombres", nombres);
                    cmd.Parameters.AddWithValue("@Apellidos", apellidos);
                    cmd.Parameters.AddWithValue("@FechaNacimiento", fechaNacimiento);
                    cmd.Parameters.AddWithValue("@Sexo", sexo);
                    cmd.Parameters.AddWithValue("@Foto", foto);
                    cmd.Parameters.AddWithValue("@Carrera", carrera);
                    cmd.Parameters.AddWithValue("@Pago", pago);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Estudiante registrado exitosamente.");
                    ImprimirRecibo(tipoDocumento, documento, nombres, apellidos, fechaNacimiento, sexo, carrera, pago);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al registrar estudiante en la base de datos: " + ex.Message);
            }
        }

        private void ImprimirRecibo(string tipoDocumento, string documento, string nombres, string apellidos, DateTime fechaNacimiento, string sexo, string carrera, decimal pago)
        {
            string recibo = $"Recibo de Inscripción\n\n" +
                            $"Tipo de Documento: {tipoDocumento}\n" +
                            $"Documento: {documento}\n" +
                            $"Nombres: {nombres}\n" +
                            $"Apellidos: {apellidos}\n" +
                            $"Fecha de Nacimiento: {fechaNacimiento.ToShortDateString()}\n" +
                            $"Sexo: {sexo}\n" +
                            $"Carrera: {carrera}\n" +
                            $"Monto Pagado: RD${pago}\n" +
                            $"Fecha: {DateTime.Now.ToShortDateString()}";

            SaveFileDialog sfd = new SaveFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf",
                FileName = $"Recibo_Inscripcion_{nombres}.pdf"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (PdfWriter writer = new PdfWriter(sfd.FileName))
                    {
                        using (PdfDocument pdf = new PdfDocument(writer))
                        {
                            Document document = new Document(pdf);
                            document.Add(new Paragraph(recibo));
                        }
                    }
                    MessageBox.Show("Recibo guardado exitosamente como PDF.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al guardar el recibo: " + ex.Message);
                }
            }
        }
    }
}
