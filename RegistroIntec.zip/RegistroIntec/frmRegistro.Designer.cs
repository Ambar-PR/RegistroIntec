﻿namespace RegistroIntec
{
    partial class frmRegistro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            pbImage = new PictureBox();
            cmbTipoDoc = new ComboBox();
            txtDoc = new TextBox();
            txtNombre = new TextBox();
            txtApellido = new TextBox();
            txtFechaNacimiento = new TextBox();
            txtSexo = new TextBox();
            txtCarrera = new TextBox();
            txtPago = new TextBox();
            btnAceptar = new Button();
            btnCancelar = new Button();
            btnCargarImagen = new Button();
            ((System.ComponentModel.ISupportInitialize)pbImage).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(37, 23);
            label1.Name = "label1";
            label1.Size = new Size(96, 15);
            label1.TabIndex = 0;
            label1.Text = "Tipo Documento";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(37, 59);
            label2.Name = "label2";
            label2.Size = new Size(70, 15);
            label2.TabIndex = 1;
            label2.Text = "Documento";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(37, 96);
            label3.Name = "label3";
            label3.Size = new Size(56, 15);
            label3.TabIndex = 2;
            label3.Text = "Nombres";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(37, 133);
            label4.Name = "label4";
            label4.Size = new Size(56, 15);
            label4.TabIndex = 3;
            label4.Text = "Apellidos";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(37, 169);
            label5.Name = "label5";
            label5.Size = new Size(103, 15);
            label5.TabIndex = 4;
            label5.Text = "Fecha Nacimiento";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(37, 208);
            label6.Name = "label6";
            label6.Size = new Size(32, 15);
            label6.TabIndex = 5;
            label6.Text = "Sexo";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(37, 250);
            label7.Name = "label7";
            label7.Size = new Size(31, 15);
            label7.TabIndex = 6;
            label7.Text = "Foto";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(37, 432);
            label8.Name = "label8";
            label8.Size = new Size(45, 15);
            label8.TabIndex = 7;
            label8.Text = "Carrera";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(37, 467);
            label9.Name = "label9";
            label9.Size = new Size(34, 15);
            label9.TabIndex = 8;
            label9.Text = "Pago";
            // 
            // pbImage
            // 
            pbImage.Location = new Point(152, 245);
            pbImage.Name = "pbImage";
            pbImage.Size = new Size(232, 178);
            pbImage.SizeMode = PictureBoxSizeMode.Zoom;
            pbImage.TabIndex = 9;
            pbImage.TabStop = false;
            // 
            // cmbTipoDoc
            // 
            cmbTipoDoc.FormattingEnabled = true;
            cmbTipoDoc.Items.AddRange(new object[] { "DNI", "Pasaporte" });
            cmbTipoDoc.Location = new Point(152, 23);
            cmbTipoDoc.Name = "cmbTipoDoc";
            cmbTipoDoc.Size = new Size(232, 23);
            cmbTipoDoc.TabIndex = 10;
            // 
            // txtDoc
            // 
            txtDoc.Location = new Point(152, 54);
            txtDoc.Name = "txtDoc";
            txtDoc.Size = new Size(232, 23);
            txtDoc.TabIndex = 11;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(152, 96);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(232, 23);
            txtNombre.TabIndex = 12;
            // 
            // txtApellido
            // 
            txtApellido.Location = new Point(152, 133);
            txtApellido.Name = "txtApellido";
            txtApellido.Size = new Size(232, 23);
            txtApellido.TabIndex = 13;
            // 
            // txtFechaNacimiento
            // 
            txtFechaNacimiento.Location = new Point(152, 169);
            txtFechaNacimiento.Name = "txtFechaNacimiento";
            txtFechaNacimiento.Size = new Size(232, 23);
            txtFechaNacimiento.TabIndex = 14;
            // 
            // txtSexo
            // 
            txtSexo.Location = new Point(152, 208);
            txtSexo.Name = "txtSexo";
            txtSexo.Size = new Size(232, 23);
            txtSexo.TabIndex = 15;
            // 
            // txtCarrera
            // 
            txtCarrera.Location = new Point(152, 429);
            txtCarrera.Name = "txtCarrera";
            txtCarrera.Size = new Size(232, 23);
            txtCarrera.TabIndex = 16;
            // 
            // txtPago
            // 
            txtPago.Location = new Point(152, 464);
            txtPago.Name = "txtPago";
            txtPago.Size = new Size(232, 23);
            txtPago.TabIndex = 17;
            // 
            // btnAceptar
            // 
            btnAceptar.Location = new Point(115, 511);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(104, 40);
            btnAceptar.TabIndex = 18;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(269, 511);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(104, 40);
            btnCancelar.TabIndex = 19;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            // 
            // btnCargarImagen
            // 
            btnCargarImagen.Location = new Point(390, 403);
            btnCargarImagen.Name = "btnCargarImagen";
            btnCargarImagen.Size = new Size(46, 20);
            btnCargarImagen.TabIndex = 20;
            btnCargarImagen.Text = "...";
            btnCargarImagen.UseVisualStyleBackColor = true;
            btnCargarImagen.Click += btnCargarImagen_Click;
            // 
            // frmRegistro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(463, 572);
            Controls.Add(btnCargarImagen);
            Controls.Add(btnCancelar);
            Controls.Add(btnAceptar);
            Controls.Add(txtPago);
            Controls.Add(txtCarrera);
            Controls.Add(txtSexo);
            Controls.Add(txtFechaNacimiento);
            Controls.Add(txtApellido);
            Controls.Add(txtNombre);
            Controls.Add(txtDoc);
            Controls.Add(cmbTipoDoc);
            Controls.Add(pbImage);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmRegistro";
            Text = "frmRegistro";
            ((System.ComponentModel.ISupportInitialize)pbImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private PictureBox pbImage;
        private ComboBox cmbTipoDoc;
        private TextBox txtDoc;
        private TextBox txtNombre;
        private TextBox txtApellido;
        private TextBox txtFechaNacimiento;
        private TextBox txtSexo;
        private TextBox txtCarrera;
        private TextBox txtPago;
        private Button btnAceptar;
        private Button btnCancelar;
        private Button btnCargarImagen;
    }
}